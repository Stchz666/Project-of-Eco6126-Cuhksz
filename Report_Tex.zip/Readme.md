# CUHKSZ LaTeX Report Template

This repository contains a LaTeX template for creating professional and well-structured reports at CUHKSZ. The template is simple yet flexible, supporting features like code presentation, tables, charts, and more. It can be customized to fit your specific requirements.

You can view and edit the template online via Overleaf using the following [link](https://www.overleaf.com/read/pqkwtjzdxtmp#f5c50c).

An example of the template in use is provided, showcasing my CSC4005 Project 1 report.

<div align="center">
  <img width="580" alt="image" src="https://github.com/user-attachments/assets/5799e04b-5053-4099-aa32-468c15e91820" />
</div>
